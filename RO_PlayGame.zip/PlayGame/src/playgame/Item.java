/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playgame;

/**
 *
 * @author Potsathron
 */
public class Item {
    private String IName;
    
    public Item(String name){
        this.IName = name;
    }
    
    public String getName(){
        return IName;
    }
    
    public String toString(){
        return IName;
    }
    
    public void Sell(){
     
    }
    
   
    
}
